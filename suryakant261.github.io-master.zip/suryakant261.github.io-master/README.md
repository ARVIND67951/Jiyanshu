Made this as a birthday present for my girlfriend during lockdown. Small attempt for virtual party.

Sample screenshot of the application .
![GitHub Logo](/images/screenshots/sample.jpg)

URL: http://suryakant261.github.io/

Technology Used: Javascript, CSS3, HTML5


## Open Normally through browser
Open index.html in browser and navigate


